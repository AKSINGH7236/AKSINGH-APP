AKSINGH APP – शुरुआती PWA डेमो

GitHub पर अपलोड करने के लिए:
1. इस ZIP को Extract करें।
2. index.html, manifest.webmanifest और sw.js को GitHub repository के main / root में अलग-अलग अपलोड करें।
3. Repository > Settings > Pages > Deploy from a branch > main > /(root) > Save चुनें।
4. कुछ मिनट बाद GitHub Pages का URL खुलेगा। HTTPS पर खोलकर Chrome मेनू से "Add to Home screen" चुन सकते हैं।

जरूरी सीमाएँ:
- यह शुरुआती डेमो है, असली सुरक्षित लॉगिन नहीं।
- पासवर्ड और जो सामग्री जोड़ेंगे वह केवल उसी फोन/ब्राउज़र में रहती है।
- localStorage को तकनीकी रूप से बायपास किया जा सकता है; इसलिए इसे संवेदनशील दस्तावेजों के लिए इस्तेमाल न करें।
- सभी मोबाइल में साझा डेटा, असली Admin-only अधिकार और सुरक्षित पासवर्ड के लिए Firebase Authentication + Firestore/Storage तथा सही Security Rules सेट करना जरूरी है।
- चैट में पहले साझा किया गया कोई पासवर्ड इस्तेमाल न करें। नया निजी पासवर्ड रखें और यहाँ न भेजें।
